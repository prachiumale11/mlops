import os
import json
import pickle
from datetime import datetime
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# Create models folder
os.makedirs("models", exist_ok=True)

# Load dataset
data = load_iris()
X, y = data.data, data.target

# Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Hyperparameters
hyperparams = [
    {"C": 0.1},
    {"C": 1.0},
    {"C": 10.0}
]

results = []

for i, params in enumerate(hyperparams):
    model = LogisticRegression(max_iter=200, C=params["C"])
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)

    version = f"v{i+1}"
    filename = f"models/model_{version}.pkl"

    with open(filename, "wb") as f:
        pickle.dump(model, f)

    results.append({
        "version": version,
        "params": params,
        "accuracy": acc,
        "timestamp": str(datetime.now())
    })

# Save metadata
with open("metadata.json", "w") as f:
    json.dump(results, f, indent=4)

print("✅ Models trained and versioned successfully!")