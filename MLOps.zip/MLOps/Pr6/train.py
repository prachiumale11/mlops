import pickle
import random
import json
import os
import numpy as np

# Load models
with open("models/model_v1.pkl", "rb") as f:
    model_v1 = pickle.load(f)

with open("models/model_v2.pkl", "rb") as f:
    model_v2 = pickle.load(f)

# Traffic split (Feature flag)
SPLIT = 0.7  # 70% to v1, 30% to v2

# Metrics storage
metrics_file = "metrics.json"

if not os.path.exists(metrics_file):
    with open(metrics_file, "w") as f:
        json.dump({"v1": {"count": 0}, "v2": {"count": 0}}, f)


def predict(input_data, true_label=None):
    # Decide which model to use
    if random.random() < SPLIT:
        model = model_v1
        version = "v1"
    else:
        model = model_v2
        version = "v2"

    prediction = model.predict([input_data])[0]

    # Update metrics
    with open(metrics_file, "r") as f:
        metrics = json.load(f)

    metrics[version]["count"] += 1

    # If ground truth available → track accuracy
    if true_label is not None:
        correct = int(prediction == true_label)
        metrics[version].setdefault("correct", 0)
        metrics[version]["correct"] += correct

    with open(metrics_file, "w") as f:
        json.dump(metrics, f, indent=4)

    return prediction, version


# Test run
if __name__ == "__main__":
    sample = [5.1, 3.5, 1.4, 0.2]
    pred, ver = predict(sample, true_label=0)

    print(f"Prediction: {pred}, Model Used: {ver}")